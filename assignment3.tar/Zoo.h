#ifndef ZOO
#define ZOO

#include "Tiger.h"
#include "SeaLion.h"
#include "BlackBear.h"

using namespace std;

class Zoo
{
private:
	int num_tigers;
	Tiger *tiger_array;
	bool adult_tiger();

	int num_sealions;
	SeaLion *sealion_array;
	bool adult_sealion();

	int num_blackbears;
	BlackBear *blackbear_array;
	bool adult_blackbear();

	float money_in_bank;

	void add_animal(string);
	void do_turn();
	void iterate_age();
	void display_zoo();
	void display_tigers();
	void display_blackbears();
	void display_sealions();
	void random_event();
	void sick_animal();//to do baby sick animal double cost-----------------------------------
	int available_rand_sick_animal();
	bool can_afford(float);
	void remove_tiger_at(int);
	void remove_blackbear_at(int);
	void remove_sealion_at(int);
	void pregnant_animal();
	int available_rand_preg_animal();
	void add_tiger_array_space();
	void add_blackbear_array_space();
	void add_sealion_array_space();
	bool good_yes_no_input(string);
	void boom_in_attendance();
	float calculate_revenue();
	void purchase_animals();
	bool good_species_choice(string);
	bool good_num_species_choice(string);
	void buy_food();
public:
	Zoo();
	~Zoo();
	void play_game();
};

#endif

