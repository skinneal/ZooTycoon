#include "BlackBear.h"


BlackBear::BlackBear()
{
	set_default_values();
	//cout << "Default Black Bear Constructor Called" << endl;
}

BlackBear::BlackBear(string baby) //nondefault constructor
{
	set_default_values();
	age = 0;
}

BlackBear::~BlackBear()
{
	//cout << "Default Black Bear Destructor Called" << endl;
}

void BlackBear::set_default_values()
{
	this->age = 48;
	this->adult = true;
	this->animal_cost = 5000;
	this->food_cost = 3 * 80;
	this->revenue = 500;
}


