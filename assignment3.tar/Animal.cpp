#include "Animal.h"


Animal::Animal()
{
	//cout << "Default Animal Constructor Called" << endl; 
}

Animal::~Animal()
{
	//cout << "Default Animal Destructor Called" << endl;
}

Animal& Animal::operator++() {
	++age;
	return *this;
}

int Animal::get_age()
{
	return this->age;
}

bool Animal::get_adult()
{
	return this->adult;
}

int Animal::get_animal_cost()
{
	return this->animal_cost;
}

float Animal::get_food_cost()
{
	return this->food_cost;
}


void Animal::set_age(int age)
{
	this->age = age;
}

void Animal::set_adult(bool adult)
{
	this->adult = adult;
}

void Animal::set_food_cost(float food_cost)
{
	this->food_cost = food_cost;
}


