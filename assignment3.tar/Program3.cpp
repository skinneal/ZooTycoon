/************************************************************
Program: Program3.cpp (Zoo Tycoon)
Author: Allison Skinner
Date: 02/10/2020
Decription: Player acts as the owner of the city's zoo, which 
has exhibits of sea lions, tigers, and black bears. Ensure the 
welfare of the animals and generate as much profit as possible.
Input: Integers
Output: Strings, Integers
*************************************************************/

#include <iostream>
#include <cstdlib>

#include "Animal.h"
#include "SeaLion.h"
#include "Tiger.h"
#include "BlackBear.h"
#include "Zoo.h"

using namespace std;

int main()
{
	Zoo zoo;
	zoo.play_game();
	return 0;
}
