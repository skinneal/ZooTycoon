#include "Tiger.h"


Tiger::Tiger()
{
	//cout << "Default Tiger Constructor Called" << endl;
	set_default_values();
}

Tiger::Tiger(string baby)
{
	set_default_values();
	age = 0;
}

Tiger::~Tiger()
{
	//cout << "Default Tiger Destructor Called" << endl;
}

void Tiger::set_default_values()
{
	this->age = 48;
	this->adult = true;
	this->animal_cost = 12000;
	this->food_cost = 5 * 80;
	this->revenue = 1200;
}


