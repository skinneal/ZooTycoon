#include "SeaLion.h"


SeaLion::SeaLion()
{
	//cout << "Default Sea Lion Constructor Called" << endl;
	set_default_values();
}

SeaLion::SeaLion(string baby) //nondefault constructor
{
	set_default_values();
	age = 0;
}

SeaLion::~SeaLion()
{
	//cout << "Default Sea Lion Destructor Called" << endl;
}

void SeaLion::set_bonus(int)
{
}

void SeaLion::set_default_values()
{
	this->age = 48;
	this->adult = true;
	this->animal_cost = 700;
	this->food_cost = 80;
	this->revenue = 140;
}

