#ifndef TIGER
#define TIGER

#include <iostream>
#include "Animal.h"

using namespace std;

class Tiger : public Animal {
public:
	Tiger();
	Tiger(string);
	~Tiger();
private:
protected:
	void set_default_values();
};

#endif
