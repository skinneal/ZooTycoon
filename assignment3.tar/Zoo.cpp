#include "Zoo.h"
#include <iostream>
#include <stdlib.h>
#include <time.h>

/*********************************************
Function: adult_tiger
Description: checks to see if there is an adult tiger
Parameters: none
Pre-Conditions: goes through list of tigers
Post-Conditions: returns true or false
**********************************************/
bool Zoo::adult_tiger()
{
	for (int i = 0; i < num_tigers; i++) {
		if (tiger_array[i].get_age() >= 48)
			return true;
	}
	return false;
}
/*********************************************
Function: adult_sealion
Description: checks to see if there is an adult sea lion
Parameters: none
Pre-Conditions: goes through list of sea lions
Post-Conditions: returns true or false
**********************************************/
bool Zoo::adult_sealion()
{
	for (int i = 0; i < num_sealions; i++) {
		if (sealion_array[i].get_age() >= 48)
			return true;
	}
	return false;
}
/*********************************************
Function: adult_blackbear
Description: checks to see if there is an adult black bear
Parameters: none
Pre-Conditions: goes through list of black bears
Post-Conditions: returns true or false
**********************************************/
bool Zoo::adult_blackbear()
{
	for (int i = 0; i < num_blackbears; i++) {
		if (blackbear_array[i].get_age() >= 48)
			return true;
	}
	return false;
}
/*********************************************
Function: add_animal
Description: adds animal to zoo
Parameters: string
Pre-Conditions: user wants new animal
Post-Conditions: animal is added to array
**********************************************/
void Zoo::add_animal(string animal)
{
	if (animal.compare("tiger") == 0) {
		add_tiger_array_space();
		Tiger temp;
		tiger_array[num_tigers-1] = temp;
	}
	if (animal.compare("sea lion") == 0) {
		add_sealion_array_space();
		SeaLion temp;
		sealion_array[num_sealions - 1] = temp;
	}
	if (animal.compare("black bear") == 0) {
		add_blackbear_array_space();
		BlackBear temp;
		blackbear_array[num_blackbears - 1] = temp;
	}
}
/*********************************************
Function: do_turn
Description: iterates animals age, displays zoo, 
random event ocurs, calculates revenue, user can buy 
animals and food
Parameters: none
Pre-Conditions: user has money in their bank
Post-Conditions: turn occurs, else bankrupt (game ends)
**********************************************/
void Zoo::do_turn() //every month, a turn
{
	if (money_in_bank > 0) {
		iterate_age();
		display_zoo();
		random_event();
		this->money_in_bank += calculate_revenue();
		purchase_animals();
		buy_food();
	}
	else {
		cout << money_in_bank << endl;
		cout << "BANKRUPT. Game Over." << endl;
		exit(0);
	}
}
/********************************************************
Function: iterate_age
Description: iterates age for each animal in the zoo
Parameters: none
Pre-Conditions: there are animals
Post-Conditions: animal becomes one month older
*******************************************************/
void Zoo::iterate_age()
{
	//iterate tiger age
	for (int i = 0; i < num_tigers; i++) {
		tiger_array[i].set_age(tiger_array[i].get_age() + 1);
		if (tiger_array[i].get_age() >= 48) {
			tiger_array[i].set_adult(true);
		}
	}
	//iterate black bear age
	for (int i = 0; i < num_blackbears; i++) {
		blackbear_array[i].set_age(blackbear_array[i].get_age() + 1);
		if (blackbear_array[i].get_age() >= 48) {
			blackbear_array[i].set_adult(true);
		}
	}
	//iterate sea lion age
	for (int i = 0; i < num_sealions; i++) {
		sealion_array[i].set_age(sealion_array[i].get_age() + 1);
		if (sealion_array[i].get_age() >= 48) {
			sealion_array[i].set_adult(true);
		}
	}
}
/*********************************************
Function: display_zoo
Description: displays money in bank and animals in the zoo
Parameters: none
Pre-Conditions: none
Post-Conditions: displays info
**********************************************/
void Zoo::display_zoo()
{
	cout << "__________________________________________________________" << endl;
	cout << "Current Balance: " << money_in_bank << endl;
	display_tigers();
	display_blackbears();
	display_sealions();
	cout << "__________________________________________________________" << endl;
}
/*****************************************************************
Function: display_tigers
Description: prints out how many of each age group of tiger
Parameters: none
Pre-Conditions: zoo has tigers
Post-Conditions: tiger age is printed
*****************************************************************/
void Zoo::display_tigers()
{
	cout << "List of Tigers: " << endl;
	for (int i = 0; i < num_tigers; i++) {
		if (tiger_array[i].get_age() <6) { //baby
			cout << " -Baby " << tiger_array[i].get_age() << " months" << endl;
		}
		if (tiger_array[i].get_age() > 48) { //adult
			cout << " -Adult " << tiger_array[i].get_age() << " months" << endl;
		}
		if (tiger_array[i].get_age() >6 && tiger_array[i].get_age() <48) { //adolescence
			cout << " -Adolescent " << tiger_array[i].get_age() << " months" << endl;
		}
	}
}
/*****************************************************************
Function: display_blackbears
Description: prints out how many of each age group of black bear
Parameters: none
Pre-Conditions: zoo has black bears
Post-Conditions: black bears age is printed
*****************************************************************/
void Zoo::display_blackbears()
{
	cout << "List of Black Bears: " << endl;
	for (int i = 0; i < num_blackbears; i++) {
		if (blackbear_array[i].get_age() < 6) { //baby
			cout << " -Baby " << blackbear_array[i].get_age() << " months" << endl;
		}
		if (blackbear_array[i].get_age() > 48) { //adult
			cout << " -Adult " << blackbear_array[i].get_age() << " months" << endl;
		}
		if (blackbear_array[i].get_age() > 6 && blackbear_array[i].get_age() < 48) { //adolescence
			cout << " -Adolescent " << blackbear_array[i].get_age() << " months" << endl;
		}
	}
}
/*****************************************************************
Function: display_sealions
Description: prints out how many of each age group of sea lion
Parameters: none
Pre-Conditions: zoo has sea lions
Post-Conditions: sea lion age is printed
*****************************************************************/
void Zoo::display_sealions()
{
	cout << "List of Sea Lions: " << endl;
	for (int i = 0; i < num_sealions; i++) {
		if (sealion_array[i].get_age() < 6) { //baby
			cout << " -Baby " << sealion_array[i].get_age()<<" months" << endl;
		}
		if (sealion_array[i].get_age() > 48) { //adult
			cout << " -Adult " << sealion_array[i].get_age()<<" months" << endl;
		}
		if (sealion_array[i].get_age() > 6 && sealion_array[i].get_age() < 48) { //adolescence
			cout << " -Adolescent " << sealion_array[i].get_age()<<" months" << endl;
		}
	}
}
/*********************************************
Function: random_event
Description: picks random event and runs
Parameters: none
Pre-Conditions: new month
Post-Conditions: random event or nothing
**********************************************/
void Zoo::random_event()
{
	srand(time(NULL));
	cout << "Random Event Occuring" << endl;
	int random_choice = rand() % 4 + 1;
	if (random_choice == 1) { //sick animal
		cout << "There is a sick animal" << endl;
		sick_animal();
	}
	if (random_choice == 2) { //gives birth
		cout << "There is a pregnant animal" << endl;
		pregnant_animal();
	}
	if (random_choice == 3) { //boom in attendance
		cout << "There's a boom in attendance" << endl;
		boom_in_attendance();
	}
	if (random_choice == 4) { //no special event
		cout << "No Special Event." << endl;
	}
}
/*********************************************
Function: sick_animal
Description: checks if the user can pay to 
heal the specific animal
Parameters: none
Pre-Conditions: there is a specific animal in 
the zoo that is sick
Post-Conditions: user pasys money to heal animal 
or the animal dies and is removed from the zoo
**********************************************/
void Zoo::sick_animal() //to do baby sick animal double cost-----------------------------------
{
	int animal_type = available_rand_sick_animal();
	if (animal_type == 0)
		cout << "No animals to get sick." << endl;
	if (animal_type == 1) { //tiger
		if (tiger_array && !can_afford(6000)) {
			int rand_animal = rand() % num_tigers;
			remove_tiger_at(rand_animal);
		}
		if (tiger_array && can_afford(6000)) {
			money_in_bank -= 6000;
		}
	}
	if (animal_type == 2) { //black bear
		if (blackbear_array && !can_afford(2500)) {
			int rand_animal = rand() % num_sealions;
			remove_blackbear_at(rand_animal);
		}
		if (blackbear_array && can_afford(2500)) {
			money_in_bank -= 2500;
		}
	}
	if (animal_type == 3) { //sea lion
		if (sealion_array && !can_afford(350)) {
			int rand_animal = rand() % num_sealions;
			remove_sealion_at(rand_animal);
		}
		if (sealion_array && can_afford(350)) {
			money_in_bank -= 350;
		}
	}
}
/***********************************************************************
Function: available_rand_sick_animal
Description: checks to see if there is an available random sick animal
Parameters: none
Pre-Conditions: there is an animal to get sick
Post-Conditions: animal gets sick, else nothing happens
************************************************************************/
int Zoo::available_rand_sick_animal()
{
	if(!tiger_array && !sealion_array && !blackbear_array)
		return 0;
	int type = 0;
	bool found = false;
	while (!found) {
		srand(time(NULL));
		type = rand() % 3 + 1;
		if (tiger_array&&type == 3) {
			found = true;
		}
		if (blackbear_array&&type == 2) {
			found = true;
		}
		if (sealion_array&&type == 1) {
			found = true;
		}
	}
	return type;
}
/*********************************************
Function: can_afford
Description: checks to see if user can afford
Parameters: float
Pre-Conditions: user is trying to buy something
Post-Conditions: return true or false
**********************************************/
bool Zoo::can_afford(float cost)
{
	if (money_in_bank < cost)
		return false;
	else
		return true;
}
/*********************************************
Function: remove_tiger_at
Description: removes tiger if user cannot heal it
Parameters: int
Pre-Conditions: tiger is in array
Post-Conditions: removes last tiger
**********************************************/
void Zoo::remove_tiger_at(int index)
{
	if (tiger_array) {
		Tiger *new_tiger_array = new Tiger[num_tigers - 1];
		for (int i = 0; i < num_tigers - 1; i++) {
			if (i < index) {
				new_tiger_array[i] = tiger_array[i];
			}
			else {
				new_tiger_array[i] = tiger_array[i + 1];
			}
		delete [] tiger_array;
		}
		num_tigers = num_tigers - 1;
		tiger_array = new_tiger_array;
	}
}
/*********************************************
Function: remove_blackbear_at
Description: removes black bear if user cannot heal it
Parameters: int
Pre-Conditions: black bear is in array
Post-Conditions: removes last black bear
**********************************************/
void Zoo::remove_blackbear_at(int index)
{
	if (blackbear_array) {
		BlackBear *new_blackbear_array = new BlackBear[num_blackbears - 1];
		for (int i = 0; i < num_blackbears - 1; i++) {
			if (i < index) {
				new_blackbear_array[i] = blackbear_array[i];
			}
			else {
				new_blackbear_array[i] = blackbear_array[i + 1];
			}
		delete [] blackbear_array;
		}
		num_blackbears = num_blackbears - 1;
		blackbear_array = new_blackbear_array;
	}
}
/*********************************************
Function: remove_sealion_at
Description: removes sea lion if user cannot heal it
Parameters: int
Pre-Conditions: sea lion is in array
Post-Conditions: removes last sea lion
**********************************************/
void Zoo::remove_sealion_at(int index)
{
	if (sealion_array) {
		SeaLion *new_sealion_array=new SeaLion[num_sealions-1];
		for (int i = 0; i < num_sealions - 1; i++) {
			if (i < index) {
				new_sealion_array[i] = sealion_array[i];
			}
			else {
				new_sealion_array[i] = sealion_array[i + 1];
			}
		delete [] sealion_array;
		}
		num_sealions = num_sealions - 1;
		sealion_array = new_sealion_array;
	}
}
/**********************************************************
Function: pregnant_animal
Description: if there's an available pregnant animal, it 
gives birth and adds an animal to the zoo
Parameters: none
Pre-Conditions: there is an available random 
pregnant animal in the zoo
Post-Conditions: animal becomes pregnant and gives birth
**********************************************************/
void Zoo::pregnant_animal()
{
	int animal_type = available_rand_preg_animal();
	if (animal_type == 0)
		cout << "No animals to get pregnant." << endl;
	if (animal_type == 1) { //tiger
		if (tiger_array && adult_tiger()) {
			add_animal("tiger");
		}
	}
	if (animal_type == 2) { //black bear
		if (blackbear_array && adult_blackbear()) {
			add_animal("black bear");
		}
	}
	if (animal_type == 3) { //sea lion
		if (sealion_array && adult_sealion()) {
			add_animal("sea lion");
		}
	}
}
/*********************************************
Function: available_rand_preg_animal
Description: checks to see if there's an available 
animal in the zoo to get pregnant
Parameters: none
Pre-Conditions: there are adult animals in the zoo
Post-Conditions: return true
**********************************************/
int Zoo::available_rand_preg_animal()
{
	if (!adult_tiger() && !adult_sealion() && !adult_blackbear())
		return 0;
	int type = 0;
	bool found = false;
	while (!found) {
		srand(time(NULL));
		type = rand() % 3 + 1;
		if (adult_tiger()&&type == 3) {
			found = true;
		}
		if (adult_blackbear()&&type == 2) {
			found = true;
		}
		if (adult_sealion()&&type == 1) {
			found = true;
		}
	}
	return type;
}
/*********************************************
Function: add_tiger_array_space
Description: adds array space in tiger array
Parameters: none
Pre-Conditions: tiger is bought/born
Post-Conditions: tiger space is added
**********************************************/
void Zoo::add_tiger_array_space()
{
	Tiger *new_tiger_array = new Tiger[num_tigers + 1];
	if (tiger_array) {
		for (int i = 0; i < num_tigers; i++) {
			new_tiger_array[i] = tiger_array[i];
		}
		delete[] tiger_array;
	}
	num_tigers = num_tigers + 1;
	tiger_array = new_tiger_array;
}
/*********************************************
Function: add_blackbear_array_space
Description: adds array space in black bear array
Parameters: none
Pre-Conditions: black bear is bought/born
Post-Conditions: black bear space is added
**********************************************/
void Zoo::add_blackbear_array_space()
{
	BlackBear *new_blackbear_array = new BlackBear[num_blackbears + 1];
	if (blackbear_array) {
		for (int i = 0; i < num_blackbears; i++) {
			new_blackbear_array[i] = blackbear_array[i];
		}
		delete [] blackbear_array;
	}
	num_blackbears = num_blackbears + 1;
	blackbear_array = new_blackbear_array;
}
/*********************************************
Function: add_sealion_array_space
Description: adds array space in sea lion array
Parameters: none
Pre-Conditions: sea lion is bought/born
Post-Conditions: sea lion space is added
**********************************************/
void Zoo::add_sealion_array_space()
{
	SeaLion *new_sealion_array = new SeaLion[num_sealions + 1];
	if (sealion_array) {
		for (int i = 0; i < num_sealions; i++) {
			new_sealion_array[i] = sealion_array[i];
		}
		delete[] sealion_array;
	}
	num_sealions = num_sealions + 1;
	sealion_array = new_sealion_array;
}
/*********************************************************************
Function: good_yes_no_input
Description: checks that the user inputted a correct choice
Parameters: string
Pre-Conditions: user input
Post-Conditions: returns true or false
**********************************************************************/
bool Zoo::good_yes_no_input(string input)
{
	if (input.compare("0") == 0 || input.compare("1") == 0)
		return true;
	return false;
}
/*****************************************************
Function: boom_in_attendance
Description: random event - sea lions provide random bonus
Parameters: none
Pre-Conditions: user owns sea lions
Post-Conditions: user receives random bonus to bank
******************************************************/
void Zoo::boom_in_attendance()
{
	if (sealion_array) {
		for (int i = 0; i < num_sealions; i++) {
			srand(time(NULL));
			sealion_array[i].set_bonus(rand() % 400 + 150);
		}
	}
}
/***************************************************************
Function: calculate_revenue
Description: calculates revenue for each animal (adult vs baby)
Parameters: none
Pre-Conditions: user owns specified animal
Post-Conditions: user receives money added to their bank
****************************************************************/
float Zoo::calculate_revenue()
{
	float end_revenue = 0;
	if (sealion_array) {
		for (int i = 0; i < num_sealions; i++) {
			int age = sealion_array[i].get_age();
			if (age <= 6)
				end_revenue += 140 * 2.0;
			if(age>6) //adolescents and adults make same revenue (unclear documentation)
				end_revenue += 140.0;
		}
	}
	if (blackbear_array) {
		for (int i = 0; i < num_blackbears; i++) {
			int age = blackbear_array[i].get_age();
			if (age <= 6)
				end_revenue += 500 * 2.0;
			if (age > 6) //adolescents and adults make same revenue (unclear documentation)
				end_revenue += 500.0;
		}
	}
	if (tiger_array) {
		for (int i = 0; i < num_tigers; i++) {
			int age = tiger_array[i].get_age();
			if (age <= 6)
				end_revenue += 1200 * 2.0;
			if (age > 6) //adolescents and adults make same revenue (unclear documentation)
				end_revenue += 1200.0;
		}
	}
	return 0;
}
/**************************************************************************************************
Function: purchase_animals
Description: asks user if they want to buy an animal, asks what species, and how many. 
Checks to see if user can afford it.
Parameters: none
Pre-Conditions: user input
Post-Conditions: prints error message or subtracts money from user's bank and gives purchased animal
***************************************************************************************************/
void Zoo::purchase_animals()
{
	string user_input = "123456789"; 
	string animal_choice = "123456789";
	cout << "Would you like to buy an animal? (0-no, 1-yes)" << endl;
	cin >> user_input;
	while (!good_yes_no_input(user_input)) {
		cout << "Bad input" << endl;
		cout << "Would you like to buy an animal? (0-no, 1-yes)" << endl;
		cin >> user_input;
	}
	if (user_input.compare("0") == 0)
		return;
	bool go_again = true;
	user_input = "123456789";
	while (go_again) {
		go_again = false;
		cout << "What species would you like to buy? (1-tiger, 2-black bear, 3-sea lion)" << endl;
		cin >> user_input;
		while (!good_species_choice(user_input)) {
			cout << "Bad input" << endl;
			cout << "What species would you like to buy? (1-tiger, 2-black bear, 3-sea lion)" << endl;
			cin >> user_input;
		}
		animal_choice = user_input;
		user_input = "123456789";
		cout << "How many would you like to buy? (1-2)" << endl;
		cin >> user_input;
		while (!good_num_species_choice(user_input)) {
			cout << "Bad input" << endl;
			cout << "How many would you like to buy? (1-2)" << endl;
			cin >> user_input;
		}
		//sea lions
		if (animal_choice.compare("3") == 0 && can_afford(700 * atoi(user_input.c_str()))) {
			for (int i = 0; i < atoi(user_input.c_str()); i++) {
				add_animal("sea lion");
				sealion_array[num_sealions - 1].set_age(48); //set age to 4 years old
				money_in_bank -= 700 * atoi(user_input.c_str());
			}
		}
		else if (animal_choice.compare("3") == 0 && !can_afford(700 * atoi(user_input.c_str()))) {
			cout << "Cannot afford animal. Try again." << endl;
			go_again = true;
		}
		//black bears
		if (animal_choice.compare("2") == 0 && can_afford(5000 * atoi(user_input.c_str()))) {
			for (int i = 0; i < atoi(user_input.c_str()); i++) {
				add_animal("black bear");
				blackbear_array[num_blackbears - 1].set_age(48); //set age to 4 years old
				money_in_bank -= 5000 * atoi(user_input.c_str());
			}
		}
		else if (animal_choice.compare("2") == 0 && !can_afford(5000 * atoi(user_input.c_str()))) {
			cout << "Cannot afford animal. Try again." << endl;
			go_again = true;
		}
		//tigers
		if (animal_choice.compare("1") == 0 && can_afford(12000 * atoi(user_input.c_str()))) {
			for (int i = 0; i < atoi(user_input.c_str()); i++) {
				add_animal("tiger");
				tiger_array[num_tigers - 1].set_age(48); //set age to 4 years old
				money_in_bank -= 12000 * atoi(user_input.c_str());
			}
		}
		else if (animal_choice.compare("1") == 0 && !can_afford(12000 * atoi(user_input.c_str()))) {
			cout << "Cannot afford animal. Try again." << endl;
			go_again = true;
		}
	}
}
/**********************************************************************
Function: good_species_choice
Description: checks that the user inputted a correct species choice
Parameters: string
Pre-Conditions: user input
Post-Conditions: returns true or false
**********************************************************************/
bool Zoo::good_species_choice(string choice)
{
	if (choice.compare("1") == 0 || choice.compare("2") == 0 || choice.compare("3") == 0)
		return true;
	return false;
}
/********************************************************************
Function: good_num_species_choice
Description: checks that the user inputted a correct species choice
Parameters: string
Pre-Conditions: user input
Post-Conditions: returns true or false
**********************************************************************/
bool Zoo::good_num_species_choice(string choice)
{
	if (choice.compare("1") == 0 || choice.compare("2") == 0)
		return true;
	return false;
}
/*****************************************************************
Function: buy_food
Description: buys each animal's food
Parameters: none
Pre-Conditions: player owns specified animal
Post-Conditions: player pays for the specified animal's food
*****************************************************************/
void Zoo::buy_food()
{
	float food_cost=0.0;
	srand(time(NULL));
	float delta_food_cost = (rand()%120+80)/100;

	for (int i = 0; i < num_sealions; i++) {
		sealion_array[i].set_food_cost(sealion_array[i].get_food_cost()*delta_food_cost);
		food_cost += sealion_array[i].get_food_cost();
	}
	for (int i = 0; i < num_blackbears; i++) {
		blackbear_array[i].set_food_cost(blackbear_array[i].get_food_cost()*delta_food_cost);
		food_cost += blackbear_array[i].get_food_cost(); 
	}
	for (int i = 0; i < num_tigers; i++) {
		tiger_array[i].set_food_cost(tiger_array[i].get_food_cost()*delta_food_cost);
		food_cost += tiger_array[i].get_food_cost(); 
	}
	if (can_afford(food_cost)) {
		money_in_bank -= food_cost;
	}
	else {
		cout << money_in_bank << endl;
		cout << "BANKRUPT. Game Over." << endl;
		exit(0);
	}
}

Zoo::Zoo()
{
	this->num_tigers = 0;
	this->tiger_array = NULL;
	this->num_sealions = 0;
	this->sealion_array = NULL;
	this->num_blackbears = 0;
	this->blackbear_array = NULL;
	this->money_in_bank = 100000;
}

Zoo::~Zoo()
{
	if (this->tiger_array)
		delete[] tiger_array;
	if (this->sealion_array)
		delete[] sealion_array;
	if (this->blackbear_array)
		delete[] blackbear_array;
}
/*********************************************
Function: play_game
Description: asks user if they want to quit
Parameters: none
Pre-Conditions: player wants to continue
Post-Conditions: game continues
**********************************************/
void Zoo::play_game()
{
	bool cont = true;
	string user_input="123456789";
	while (cont) {
		do_turn();
		user_input = "123456789";
		cout << "Do you want to quit? (0-no, 1-yes)" << endl;
		cin >> user_input;
		while (!good_yes_no_input(user_input)) {
			cout << "Bad input." << endl;
			user_input = "123456789";
			cout << "Do you want to quit? (0-no, 1-yes)" << endl;
			cin >> user_input;
		}
		if (user_input.compare("1") == 0)
			cont = false;
	}
	
}


