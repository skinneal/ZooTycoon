#ifndef BLACKBEAR
#define BLACKBEAR

#include <iostream>
#include "Animal.h"

using namespace std; 

class BlackBear : public Animal {
public:
	BlackBear();
	BlackBear(string);
	~BlackBear();
private:
protected:
	void set_default_values();
};

#endif
