#ifndef ANIMAL
#define ANIMAL

#include <iostream>
#include <string>


using namespace std;

class Animal {
public:
	Animal();
	~Animal();
	Animal& operator++(); //pre-increment
	//getters
	int get_age();
	bool get_adult();
	int get_animal_cost();
	float get_food_cost();
	//int get_revenue();
	//setters
	void set_age(int);
	void set_adult(bool);
	//void set_animal_cost(int);
	void set_food_cost(float);
	//void set_revenue(int);
private:
protected:
	int age;
	bool adult;
	int animal_cost;
	float food_cost;
	int revenue;
};

#endif
