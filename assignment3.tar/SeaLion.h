#ifndef SEALION
#define SEALION

#include <iostream>
#include "Animal.h"

using namespace std;

class SeaLion : public Animal {
public:
	SeaLion();
	SeaLion(string);
	~SeaLion();
	//getters
	//int get_bonus();
	//setters
	void set_bonus(int);
private:
protected:
	void set_default_values();
};

#endif

